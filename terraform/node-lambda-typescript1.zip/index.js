"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var lambda_1 = require("./src/lambda");
Object.defineProperty(exports, "handler", { enumerable: true, get: function () { return lambda_1.handler; } });
