"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var axios_1 = require("axios");
function handler(event) {
    console.log('==> ', event);
    return axios_1.default.get("https://reqres.in/api/users").then(function (response) {
        console.log(response.data.data);
        return Promise.resolve(response.data.data);
    });
    // return Promise.resolve(event);
}
exports.handler = handler;
